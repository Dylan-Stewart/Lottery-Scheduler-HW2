#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h" // 🔥

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// ⭐ first hw assignment ⭐
// returns how many times that the read() system call has been called by user processes since the time that the kernel was booted.

int sys_getreadcount(void) // ⭐ 
{

return myproc()->readcalls;
}

// 🔥 second hw assignment 🔥

//function to set the tickets for the lottery test
//calling this routine makes it such that a process can raise the number of tickets it receives, and thus receive a higher proportion of CPU cycles. This routine should return 0 if successful, and -1 otherwise

int sys_settickets(void) { // 🔥
    int x;
    //struct pstat* ps;

    if(argint(0, &x) < 0)
        return -1;

    //acquire(&ptable.lock); 🔥 removed because you can't access table in here without .h that causes errors
    myproc()->tickets = x;
    //release(&ptable.lock); 🔥 removed because you can't access table in here .h that causes errors
    return 0;
}

 // This routine returns some information about all running processes, including how many times each has been chosen to run and the process ID of each, and save them in the pstat structure in the parameters list. You can use this system call to build a variant of the command line program ps, which can then be called to see what is going on
int sys_getpinfo(void) { // 🔥
    struct pstat* procstaterino;
	if(argptr(0, (char**)&procstaterino, sizeof(procstaterino) < 0)){ // fail check
	return -1;
	}
	getmypinfo(procstaterino);
return 0;
}
