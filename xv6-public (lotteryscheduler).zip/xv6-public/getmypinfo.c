#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"



#define check(exp, msg) if(exp) {} else {\
   printf(1, "%s:%d check (" #exp ") failed: %s\n", __FILE__, __LINE__, msg);\
   exit();}

int
main(int argc, char *argv[])
{
    struct pstat* ps;
    if(argint(0, (int*)(&ps)) < 0)
		return -1;

    acquire(&ptable.lock);
    int i = 0;
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
        ps->inuse[i] = p->inuse;
        ps->tickets[i] = p->tickets;
        ps->pid[i] = p->pid;
        ps->ticks[i] = p->ticks;
        i++;
    }
    release(&ptable.lock);
    return 0;
}
